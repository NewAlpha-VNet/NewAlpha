# AlphaSwitch methods
from .newalpha import AlphaSwitch

# AlphaClient methods
from .newalpha import AlphaClient