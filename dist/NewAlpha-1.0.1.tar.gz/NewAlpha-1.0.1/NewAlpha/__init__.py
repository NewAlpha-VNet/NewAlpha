from newalpha import AlphaClient, AlphaSwitch

# AlphaSwitch methods
from newalpha import switchSetup, startLog, stopLog, getNewestLog, getFullLog, handleTraffic

# AlphaClient methods
from newalpha import clientSetup, bridge, responseFlag, registerSwitch, request, encode_format, frozenResponse, dynamicResponse, confirmationResponse
