# Classes
from .newalpha import AlphaClient, AlphaSwitch

# AlphaSwitch methods
from .newalpha import AlphaSwitch

# AlphaClient methods
from .newalpha import AlphaClient